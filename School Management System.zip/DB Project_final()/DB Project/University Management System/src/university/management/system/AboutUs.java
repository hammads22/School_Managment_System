package university.management.system;

import java.awt.*;
import javax.swing.*;

public class AboutUs extends JFrame{

	private JPanel contentPane;

//        public static void main(String[] args) {
//            
//            new Login().setVisible(true);
//            
//	}
    
        public AboutUs() {
            
            super("About Us");
            setBackground(new Color(173, 216, 230));
            setBounds(500, 250, 1000, 1000);
		
            contentPane = new JPanel();
            setContentPane(contentPane);
            contentPane.setLayout(null);

            JLabel l1 = new JLabel("ICON");
            ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/logo.jpg"));
            Image i2 = i1.getImage().getScaledInstance(400, 300,Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            l1 = new JLabel(i3);
            l1.setBounds(400, 40, 400, 300);
            contentPane.add(l1);


            JLabel l3 = new JLabel("Made By:");
            l3.setForeground(Color.BLACK);
            l3.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 34));
            l3.setBounds(20, 40, 200, 55);
            contentPane.add(l3);

            JLabel l4 = new JLabel("Rohail Naushad");
            l4.setForeground(Color.ORANGE);
            l4.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 26));
            l4.setBounds(20,70,200,55);
            contentPane.add(l4);

            JLabel l5 = new JLabel("Hammad Shahid");
            l5.setForeground(Color.ORANGE);
            l5.setFont(new Font("Trebuchet MS", Font.BOLD, 26));
            l5.setBounds(20,100,200,55);
            contentPane.add(l5);

            JLabel l6 = new JLabel("Daniyal Ahmed");
            l6.setForeground(Color.ORANGE);
            l6.setFont(new Font("Trebuchet MS", Font.BOLD, 26));
            l6.setBounds(20, 130, 200, 55);
            contentPane.add(l6);
                
            contentPane.setBackground(Color.WHITE);
	}
        

}


